const SUPABASE_URL = window.HELPY_SUPABASE_URL || "";
const SUPABASE_ANON_KEY = window.HELPY_SUPABASE_ANON_KEY || "";
let supabaseClient = null;
if (SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase) {
  supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}
