// Replace these values with your Supabase project URL and anon public key.
// Do NOT put a Supabase service_role key in this file.
window.HELPY_SUPABASE_URL = "";
window.HELPY_SUPABASE_ANON_KEY = "";
