-- HELPY GLOBAL — Supabase database
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  phone text default '',
  country text default '',
  city text default '',
  avatar_url text default '',
  created_at timestamptz not null default now()
);

create table if not exists listings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  type text not null check (type in ('product','service')),
  title text not null,
  description text default '',
  price numeric(14,2) default 0,
  currency text not null default 'USD',
  category text default '',
  country text default '',
  location text default '',
  contact text default '',
  image_url text default '',
  quantity integer default 1,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists businesses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  name text not null,
  category text not null default '',
  description text default '',
  phone text default '',
  whatsapp text default '',
  country text default '',
  address text default '',
  location text default '',
  image_url text default '',
  rating numeric(3,2) not null default 0,
  review_count integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists favorites (
  user_id uuid references auth.users(id) on delete cascade,
  listing_id uuid references listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, listing_id)
);

create table if not exists reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  business_id uuid references businesses(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  comment text default '',
  created_at timestamptz not null default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid references auth.users(id) on delete set null,
  receiver_id uuid references auth.users(id) on delete set null,
  body text not null,
  created_at timestamptz not null default now()
);

alter table profiles enable row level security;
alter table listings enable row level security;
alter table businesses enable row level security;
alter table favorites enable row level security;
alter table reviews enable row level security;
alter table messages enable row level security;

create policy "Public can view active listings" on listings for select using (status = 'active');
create policy "Users can create listings" on listings for insert to authenticated with check (auth.uid() = user_id);
create policy "Owners can update listings" on listings for update to authenticated using (auth.uid() = user_id);
create policy "Owners can delete listings" on listings for delete to authenticated using (auth.uid() = user_id);

create policy "Public can view businesses" on businesses for select using (true);
create policy "Authenticated users can create businesses" on businesses for insert to authenticated with check (auth.uid() = user_id);
create policy "Owners can update businesses" on businesses for update to authenticated using (auth.uid() = user_id);

create policy "Users manage own profile" on profiles for all to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Users manage own favorites" on favorites for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Public can view reviews" on reviews for select using (true);
create policy "Authenticated users can review" on reviews for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can view own messages" on messages for select to authenticated using (auth.uid() = sender_id or auth.uid() = receiver_id);
create policy "Users can send messages" on messages for insert to authenticated with check (auth.uid() = sender_id);

-- Automatically create a profile when a user registers.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
