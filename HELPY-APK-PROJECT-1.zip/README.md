# HELPY 2.0 GLOBAL — Vercel + Supabase

HELPY is a worldwide marketplace: **Buy • Sell • Offer Services • Find Services • Discover Businesses**.

## Stack
- Vercel for hosting
- Supabase for PostgreSQL + Authentication
- GitHub for source control
- Mobile-first responsive frontend

## Setup
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase-schema.sql`.
3. Copy the Supabase Project URL and public `anon` key into `public/config.js`.
4. Push this project to GitHub.
5. Import the GitHub repository into Vercel.
6. Deploy.

Never put the Supabase `service_role` key in the frontend.

## Global support
Country, city/area and currency are fields on listings. USD is the default; HTG and other currencies are supported. Haiti is supported but HELPY is designed for worldwide use.

## Important
This version removes the Railway/Express deployment dependency. Vercel serves the frontend while Supabase provides the database and authentication.
